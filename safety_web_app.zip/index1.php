<?php
include('db/conn.php');
$location=$_POST['location'];
$no = $_POST['no'];
$contact = $_POST['contact'];


echo $location.' '.$no.' '.$contact;

$q = mysqli_query($conn,"insert into register (location,mobno,contactno) values('$location','$no','$contact')");
if($q){
    echo "successsso";
}
?>