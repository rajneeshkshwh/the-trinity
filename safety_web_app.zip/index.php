<?php
include('db/conn.php');
$name=$_POST['name'];
$mobile_no = $_POST['mobile_no'];
$adharcard = $_POST['adharcard'];
$pass = $_POST['password'];

echo $name.' '.$mobile_no.' '.$adharcard.' '.$pass;

$q = mysqli_query($conn,"insert into register (Name,Email,Phone_no,Adhar_No,Password) values('$name','','$mobile_no','$adharcard','$pass')");
if($q){
    echo "successsso";
}
?>

